package com.example.pmproject.Controller;


@Controller
@RequiredArgsConstructor
public class AskController {
    private final AskService askService;
    private final AskCommentService askCommentService;

    @GetMapping("/Ask/register")
    public String registerForm(AskDTO askDTO) throws Exception {
        AskDTO askDTO = new AskDTO();

        model.addAttribute("askDTO", askDTO);
        return "Ask/regoster"
    }
    @PostMapping("ask/register")
    public String registerProc(AskDTO askDTO) throws Exception {
        if(bindingResult.hasErrors()) {
            return "ask/register";
        }
        askService.create(askDTO);
        return "redirect:/ask/list";
    }

}
