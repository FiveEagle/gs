package com.example.pmproject.Service;

import com.example.pmproject.Constant.Role;
import com.example.pmproject.Controller.AskCommentController;
import com.example.pmproject.Repository.AskCommentRepository;

@Service
@RequiredArgsConstructor
@Transactional
public class AskCommentService {
    private final AskCommentRepository askCommentRepository;
    private final ModelMapper modelMapper = new ModelMapper();

    public void remove(Integer id) throws Exception {
        askCommentRepository.deleteById(id);
    }

    public void modify(AskCommentDTO askCommentDTO) throws Exception {
        Integer id = askCommentDTO.getId();

        Optional<AskCommentEntity> read = askCommentRepository.findById(id);
        AskCommentEntity askCommentEntity = read.orElseThrow();

        AskCommentEntity update = modelMapper.map(askCommentDTO, AskCommentEntity.class);

        askCommentRepository.save(update);
    }
    public void create(int id, AskCommentDTO askCommentDTO) throws Exception {
       Opional<AskCommentEntity>  askCommentEntities = askCommentRepository.findById(id);

    AskCommentEntitiy askCommentEntitiy = data.orElseThrow();

    return askCommentDTO;
    }
}
