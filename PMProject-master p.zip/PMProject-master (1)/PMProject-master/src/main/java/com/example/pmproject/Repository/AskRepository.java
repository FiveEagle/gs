package com.example.pmproject.Repository;

import com.example.pmproject.Entity.Ask;
import org.springframework.data.jpa.repository.JpaRepository;

@Repository

public interface AskRepository extends JpaRepository<Ask, Long> {

    @Query(value= "SELECT * FROM Comment WHERE = :Ask id");


}
