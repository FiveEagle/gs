package com.example.pmproject.Controller;

@Controller
@RequiredArgsConstructor

public class AskCommentController {
    private final AskCommentService askCommentService;

    @PostMapping("/askcomment/register")

    public String registerProc(int no, AskCommentDTO askCommentDTO
    , RedirectAttributes redirectAttributes) throws Exception {

        askCommentService.create(no, askCommentDTO);

        redirectAttributes.addAttribute("id", no);
        return "redirect:/ask/read";
    }


}
