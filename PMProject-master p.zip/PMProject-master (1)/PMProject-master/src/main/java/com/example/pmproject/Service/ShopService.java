package com.example.pmproject.Service;

public class ShopService {
}
