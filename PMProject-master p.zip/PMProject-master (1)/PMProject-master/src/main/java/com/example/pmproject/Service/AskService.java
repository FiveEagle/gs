package com.example.pmproject.Service;

import com.example.pmproject.Constant.Role;
import com.example.pmproject.Controller.AskController;
import com.example.pmproject.DTO.AskDTO;

@Service
@RequiredArgsConstructor
@Transactional

public class AskService {

    private final AskRepository askRepository;
    private final ModelMapper modelMapper = new ModelMapper();

    //삭제
    public void remove(AskDTO askdto) throws Exception {
        askRepository.deleteByID();
    }
    //수정
    public void modify(AskDTO askDTO) throws Exception {
        int id = askDTO.getID();
        Optional<AskEntity> read = askRepository.findById(id);
        AskEntity askEntity = read.orElseThrow();
    }

    public Page<AskDTO> list(pageable page, String type, String keyword) throws Exception {
       int curPage = page.getPageNumber()-1;
       int pageLimit = 5;

       Page<AskEntity> askEntities;

       if(type.equals("") && keyword != null) {
           askEntities = askrepository.(pageable, keyword);
       }

       page<AskDTO> askDTOS = askEntities.map(data -> AskDTO.builder());
    }
}








